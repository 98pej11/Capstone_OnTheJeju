package capstone.jejuTourrecommend.domain;

public enum Category {
    VIEW,PRICE,FACILITY,SURROUND;
}
